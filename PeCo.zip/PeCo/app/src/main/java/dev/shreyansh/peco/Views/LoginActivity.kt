package dev.shreyansh.peco.Views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import dev.shreyansh.peco.R

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}
